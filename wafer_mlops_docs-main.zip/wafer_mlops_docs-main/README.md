[![ci](https://github.com/c17hawke/wafer_mlops_docs/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/c17hawke/wafer_mlops_docs/actions/workflows/ci.yml)

## Visit docs at [wafer mlops docs](https://c17hawke.github.io/wafer_mlops_docs/)

## Main project repository [mlops main](https://github.com/c17hawke/mlops_main)
