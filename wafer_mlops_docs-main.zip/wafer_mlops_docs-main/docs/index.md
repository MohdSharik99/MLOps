# WAFER ML-OPS docs

## Prerequisites

### For the overview of the Wafer project refer this video -

<iframe width="630" height="330" src="https://www.youtube.com/embed/rsNAb1KmvFI?start=25157" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

### For mlflow overview refer - 

<iframe width="630" height="330" src="https://www.youtube.com/embed/3XSfxv5RMxE?start=7" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>