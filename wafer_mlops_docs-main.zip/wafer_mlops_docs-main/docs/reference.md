# Important references -

### 1. MLflow Documentation

[Visit site](https://mlflow.org/docs/latest/index.html){ .md-button }

### 2. DVC Documentation

[Visit site](https://dvc.org/doc){ .md-button }

### 3. Cookiecutter Data Science documentation
[Visit site](https://drivendata.github.io/cookiecutter-data-science/){ .md-button }

### 4. MLOps: Continuous delivery and automation pipelines in machine learnings
[Visit site](https://cloud.google.com/solutions/machine-learning/mlops-continuous-delivery-and-automation-pipelines-in-machine-learning){ .md-button }

### 5. Python logging module
[Visit site](https://docs.python.org/3/howto/logging.html){ .md-button }

